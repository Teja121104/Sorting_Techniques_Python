#array operations program to consider a list arr=[10,20,30,40] perform insert operation with 50 and 25 at position 2  and deletion 30 operationwith 50 and 25 respectiovely and travers the array to fetch a number 25 is present or not.

#program
arr=[10,20,30,40]
#insert
arr.append(50)
arr.insert(2,25)
print(arr)
#delete
arr.remove(30)
arr.pop()
#traversal
for i in arr:
    print(i,end=' ')
#Searchiong
print("\n 25 in array?",25 in arr)
#oputput
#[10, 20, 25, 30, 40, 50]
#10 20 25 40 
#25 in array? True