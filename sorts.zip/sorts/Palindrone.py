#program to check whether the given string is palindrone or not 
#and count the palindromic repeated count

#program

#str=madam
#output:{'m':2,'a':2,'d':1}
#str=malayalam
text=input("Enter the name")
if text==text[::-1]:
    print("pLindrone")
else:
    print("No IT IS NOT A PALINDRONE]")
freq={}
for ch in text:
    freq[ch]=freq.get(ch,0)+1
print(freq)