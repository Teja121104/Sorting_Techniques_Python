#linear search:in sorted or unsorted
'''
1.arr of list of size n
2.key for search element
3.start with zero index value
4.compare arr[i]==key
arr[i]=key return index
else not(move to next index)
5.repeat same step till n-1
6.if no match return -1 '''
def linear_search(arr,key):
    for  i in range(len(arr)):
        if arr[i]==key:
            return 1
    return -1

size=int(input("Enter the size of array:"))
arr=[]
print("Enter the elements:")
for i in range(size):
    num=int(input(f"Element{i+1}:"))
    arr.append(num)
key=int(input("Enter the element to search:"))
result=linear_search(arr,key)
if result!=-1:
    print(f"\n Element {key} found arr {result}")
else:
    print(f"\n Element {key} not found in the array")
