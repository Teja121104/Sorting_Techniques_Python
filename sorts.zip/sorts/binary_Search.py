''' binary search:
1.array msut be sorted
2.array is divided into 2 sepersate equvivalent halfs
3.set low and high 0->n-1
4.condiition low<=high
mid=low+high//2
arr[mid]==key return mid
arr[mid]<key low mid+1
arr[mid]>key high mid-1
not found return -1'''
def Binary_search(arr,key):
    low=0
    high=len(arr)-1
    while low<=high:
        mid=(low+high)//2
        if arr[mid]==key:
            return mid
        elif arr[mid<key]:
            low=mid+1
        else:
            low=mid+1

size=int(input("Enter the size of array:"))
arr=[]
print("Enter the elements:")
for i in range(size):
    num=int(input(f"Element{i+1}:"))
    arr.append(num)
key=int(input("Enter the element to search:"))
result=Binary_search(arr,key)
if result!=-1:
    print(f"\n Element {key} found arr {result}")
else:
    print(f"\n Element {key} not found in the array")
